clear variables
clc

manipulator('C:\Users\rovai\Documents\GitHub\Automacion_FINAL\ENTREGA\Vision\EntregaImages\Ejemplo2.png');

%Otros archivos de interes son Ejemplo1.png (consigna), Ejemplo2.png y
%Ejemplo3.png