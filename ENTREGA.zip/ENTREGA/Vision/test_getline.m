[x1, y1, x2, y2] = get_line('C:\Users\rovai\Documents\GitHub\Automacion_FINAL\Ej3\images\example_image_1.png')

